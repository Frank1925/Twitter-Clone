# Twitter Simulation

## System Architecture

![System Architecture](https://github.com/shailesh-nyk/Twitter_SANAF/blob/master/System_Arch.jpg)

